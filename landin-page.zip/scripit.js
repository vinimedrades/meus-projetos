window.sr = ScrollReveal({ reset: true });

sr.reveal('.presentation h1', {
    rotate: { x: 40, y:0, z: 0},
    duration: 2000
});

sr.reveal('.presentation h3', {
    rotate: { x: 40, y:0, z: 0},
    duration: 2000
});

sr.reveal('.presentation-button',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.about-us h2',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.box-about',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.box-about2',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.box-about3',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.services h1',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.services h2',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.services p',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.services ul',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.services button',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.testimonials h2',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.testimonials p',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.faq h2',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.faq .faq-button',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.faq h3',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.faq p',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.presentation-img',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.presentation-img2',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.services-img',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.services-img2',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.sale h1',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.box-white',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.box1',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

sr.reveal('.sale p',{
    rotate: { x: 40, y: 0, z: 0},
    duration: 2000
});

